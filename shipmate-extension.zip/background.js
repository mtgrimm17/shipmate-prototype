// Cross-tab coordinator for the AUTOMATED path (Shipmate-triggered).
//
// createApp runs through chrome.debugger (CDP): it drives App Store Connect with
// TRUSTED navigation and input, because (1) cold-loading a deep SPA route from a
// content script breaks ASC's router, and (2) the Bundle ID list only loads on a
// real (trusted) click. CDP clears both. autoPrivacy still uses the content-script
// path (pendingAscTask → content-asc runPending).

const ASC_ORIGIN = 'https://appstoreconnect.apple.com';

// ---- managed tabs (ones we opened) ----------------------------------------
async function markManaged(id) {
  const { managedAscTabs = [] } = await chrome.storage.local.get('managedAscTabs');
  if (!managedAscTabs.includes(id)) await chrome.storage.local.set({ managedAscTabs: managedAscTabs.concat(id) });
}
async function isManaged(id) {
  const { managedAscTabs = [] } = await chrome.storage.local.get('managedAscTabs');
  return managedAscTabs.includes(id);
}
async function unmarkManaged(id) {
  const { managedAscTabs = [] } = await chrome.storage.local.get('managedAscTabs');
  await chrome.storage.local.set({ managedAscTabs: managedAscTabs.filter((x) => x !== id) });
}
async function closeManaged(id) { await unmarkManaged(id); try { await chrome.tabs.remove(id); } catch (_) {} }

function relayResult(task, result) {
  chrome.storage.local.set({ ascTaskResult: { task, result, ts: Date.now() } });
  chrome.tabs.query({ url: 'https://mtgrimm17.github.io/shipmate-prototype/*' }, (tabs) => {
    (tabs || []).forEach((t) => chrome.tabs.sendMessage(t.id, { type: 'ascTaskResult', task, result }, () => void chrome.runtime.lastError));
  });
}

// ---- CDP primitives --------------------------------------------------------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function cdp(tabId, method, params) {
  return new Promise((res, rej) => {
    chrome.debugger.sendCommand({ tabId }, method, params || {}, (r) => {
      const e = chrome.runtime.lastError;
      if (e) rej(new Error(e.message)); else res(r);
    });
  });
}
function attach(tabId) {
  return new Promise((res, rej) => chrome.debugger.attach({ tabId }, '1.3', () => {
    const e = chrome.runtime.lastError; if (e) rej(new Error(e.message)); else res();
  }));
}
function detach(tabId) { return new Promise((res) => { try { chrome.debugger.detach({ tabId }, () => { void chrome.runtime.lastError; res(); }); } catch (_) { res(); } }); }

async function evaluate(tabId, expression) {
  const r = await cdp(tabId, 'Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
  if (r && r.exceptionDetails) throw new Error('eval: ' + (r.exceptionDetails.text || JSON.stringify(r.exceptionDetails)));
  return r && r.result ? r.result.value : undefined;
}
async function waitFor(tabId, boolExpr, timeout = 20000, every = 300) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) { if (await evaluate(tabId, '!!(' + boolExpr + ')')) return true; await sleep(every); }
  return false;
}
// Center of the element an expression returns (after scrolling it into view).
async function rectOf(tabId, elExpr) {
  return evaluate(tabId, `(() => { const el = ${elExpr}; if (!el) return null; el.scrollIntoView({block:'center',inline:'center'}); const r = el.getBoundingClientRect(); return {x:r.left+r.width/2, y:r.top+r.height/2, w:r.width, h:r.height}; })()`);
}
async function clickAt(tabId, x, y) {
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
}
async function clickEl(tabId, elExpr) {
  const b = await rectOf(tabId, elExpr);
  if (!b || b.w === 0 || b.h === 0) return false;
  await clickAt(tabId, b.x, b.y);
  return true;
}
async function typeText(tabId, text) { await cdp(tabId, 'Input.insertText', { text }); }

// ---- createApp over CDP ----------------------------------------------------
const J = JSON.stringify;  // safe string embedding in evaluated expressions

async function cdpCreateApp(tabId, data) {
  const log = (...a) => console.log('[Shipmate CDP]', ...a);
  const bundleId = data.bundleId || '';
  if (bundleId && !bundleId.endsWith('.test')) return { ok: false, error: `Refusing to create an app for "${bundleId}": only .test bundle IDs may be used.` };
  const name = data.name || 'App - Mark Demo';
  const sku = data.sku || 'mark_demo_app';

  await attach(tabId);
  try {
    // 1) Real navigation to root, then IN-APP nav to Apps so routing initializes.
    await cdp(tabId, 'Page.enable');
    // Pretend the (background) tab is focused so Chrome doesn't throttle its timers
    // /rAF — that lets a heavy SPA render and run normally while hidden.
    try { await cdp(tabId, 'Emulation.setFocusEmulationEnabled', { enabled: true }); } catch (_) {}
    await cdp(tabId, 'Page.navigate', { url: ASC_ORIGIN + '/' });
    await waitFor(tabId, `document.getElementById('new-app-btn-icon') || [...document.querySelectorAll('a,button')].some(e => e.textContent.trim()==='Apps')`, 30000);
    if (!await evaluate(tabId, `!!document.getElementById('new-app-btn-icon')`)) {
      log('clicking Apps nav');
      await clickEl(tabId, `[...document.querySelectorAll('a,button,[role="link"]')].find(e => e.textContent.trim()==='Apps')`);
      if (!await waitFor(tabId, `!!document.getElementById('new-app-btn-icon')`, 25000)) return { ok: false, error: 'could not reach the Apps page' };
    }

    // 2) Open the New App dialog: "+" then the "New App" menu item.
    await clickEl(tabId, `document.getElementById('new-app-btn-icon')`);
    await waitFor(tabId, `document.getElementById('new-app-btn') || [...document.querySelectorAll('button,a,[role="menuitem"]')].some(e => /^new app$/i.test(e.textContent.trim()))`, 8000);
    await clickEl(tabId, `document.getElementById('new-app-btn') || [...document.querySelectorAll('button,a,[role="menuitem"]')].find(e => /^new app$/i.test(e.textContent.trim()))`);
    if (!await waitFor(tabId, `!!document.getElementById('name')`, 12000)) return { ok: false, error: 'New App dialog did not open' };

    // 3) macOS platform (trusted click so React registers it).
    await clickEl(tabId, `document.getElementById('platformsById.MAC_OS')`);

    // 4) Name — focus the field and type.
    await clickEl(tabId, `document.getElementById('name')`);
    await typeText(tabId, name);

    // 5) Primary Language — set by value (static list, present immediately).
    await evaluate(tabId, `(() => { const s=document.getElementById('primaryLocale'); if(!s) return; const o=[...s.options].find(o=>/english \\(u\\.s\\.\\)/i.test(o.textContent)); if(o){ const set=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set; set.call(s,o.value); s.dispatchEvent(new Event('input',{bubbles:true})); s.dispatchEvent(new Event('change',{bubbles:true})); } })()`);

    // 6) Bundle ID — trusted-click to trigger ASC's lazy fetch, wait for options,
    // then SELECT in a way React registers. Try three methods, checking whether
    // Create enables after each, and log the dropdown structure for diagnosis.
    const createExpr0 = `[...document.querySelectorAll('button')].find(b => b.textContent.trim()==='Create')`;
    const createEnabled = () => evaluate(tabId, `(() => { const b=${createExpr0}; return !!(b && !b.disabled); })()`);
    // Judge bundle selection by the VALUE being set — NOT by Create-enabled, which
    // also needs SKU (filled later). Checking Create here wrongly looked like a
    // failure and returned early before SKU was typed.
    const bundleSet = () => evaluate(tabId, `(() => { const s=document.getElementById('bundleId'); return !!(s && s.value===${J(bundleId)}); })()`);
    await clickEl(tabId, `document.getElementById('bundleId')`);
    const loaded = await waitFor(tabId, `(() => { const s=document.getElementById('bundleId'); return s && s.options && s.options.length>1 && ![...s.options].some(o=>/loading/i.test(o.textContent)); })()`, 25000);
    log('bundle options loaded =', loaded);
    if (!loaded) return { ok: false, error: 'Bundle ID list never loaded (still "Loading…") even with a trusted click.' };

    const diag = await evaluate(tabId, `(() => { const s=document.getElementById('bundleId'); const r=s.getBoundingClientRect(); return { roleOptions: document.querySelectorAll('[role="option"]').length, listboxes: document.querySelectorAll('[role="listbox"]').length, bidW: Math.round(r.width), bidH: Math.round(r.height), bidHidden: r.width===0||r.height===0 }; })()`);
    log('bundle diag =', diag);

    // It's a NATIVE <select> (no DOM listbox). Close the OS popup our load-click
    // opened, then select via TRUSTED keyboard type-ahead on the FOCUSED-but-CLOSED
    // select — that changes the value inline and fires a trusted change (committing
    // in the open OS popup doesn't work over CDP). The prefix to type is the game
    // name (option text is "<game> - <bundle id>").
    const typeAhead = (data.name || 'Monster Train 2').split(' - ')[0].split(/\s+/)[0].toLowerCase().replace(/[^a-z0-9]/g, '');
    // Close the OS select popup our load-click opened WITHOUT pressing Escape —
    // Escape closes the whole New App dialog. Clicking a neutral field dismisses
    // the popup and leaves the dialog open.
    await clickEl(tabId, `document.getElementById('name')`);
    await sleep(250);
    if (!await evaluate(tabId, `!!document.getElementById('bundleId')`)) return { ok: false, error: 'New App dialog closed unexpectedly before selecting the bundle' };

    let done = false;
    for (let b = 0; b < 2 && !done; b++) {
      await evaluate(tabId, `(() => { const b=document.getElementById('bundleId'); if(b) b.focus(); })()`);
      await sleep(150);
      for (const ch of typeAhead) {
        await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', text: ch, key: ch });
        await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: ch });
        await sleep(80);
      }
      await sleep(400);
      let val = await evaluate(tabId, `document.getElementById('bundleId').value`);
      done = await bundleSet();
      log('type-ahead attempt', b, '| typed "' + typeAhead + '" | value =', val, '| Create enabled =', done);
      if (!done) {   // blur can commit a pending selection and fire change
        await evaluate(tabId, `document.getElementById('bundleId').blur()`);
        await sleep(300);
        done = await bundleSet();
        log('after blur → value =', await evaluate(tabId, `document.getElementById('bundleId').value`), '| Create enabled =', done);
      }
    }
    // Fallback — set the value + fire change (works only if ASC reads native value).
    if (!done) {
      await evaluate(tabId, `(() => { const s=document.getElementById('bundleId'); const o=[...s.options].find(o=>o.value===${J(bundleId)}||(o.textContent||'').includes(${J(bundleId)})); if(o){ const set=Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype,'value').set; set.call(s,o.value); s.dispatchEvent(new Event('input',{bubbles:true})); s.dispatchEvent(new Event('change',{bubbles:true})); } })()`);
      await sleep(500);
      done = await bundleSet();
      log('value-set fallback → Create enabled =', done);
    }
    if (!done) return { ok: false, error: 'could not set the Bundle ID value (' + bundleId + ') — see [Shipmate CDP] logs' };

    // 7) SKU — focus and type.
    await clickEl(tabId, `document.getElementById('sku')`);
    await typeText(tabId, sku);

    // 8) Full Access.
    await clickEl(tabId, `document.getElementById('userAccessFull')`);
    await sleep(300);

    // 9) Create — wait for it to enable, then click.
    const createExpr = `[...document.querySelectorAll('button')].find(b => b.textContent.trim()==='Create')`;
    const enabled = await waitFor(tabId, `(() => { const b=${createExpr}; return b && !b.disabled; })()`, 8000);
    log('Create enabled =', enabled);
    if (!enabled) return { ok: false, error: 'Create button did not enable — a required field is missing (bundle likely not registered in React state).' };
    await clickEl(tabId, createExpr);

    // 10) Confirm creation — POSITIVELY. The old check also treated the Create
    //     button vanishing (`!b`) as success, so a dialog that merely closed or
    //     reset on Apple's validation error (duplicate NAME or SKU) reported a
    //     create that never happened — the step went green and the upload failed
    //     three steps later with "No app record". Now success means ONE thing:
    //     ASC navigated to the new app's page (/apps/<id>). A lingering dialog
    //     with an inline error is a failure we surface verbatim.
    //     Three outcomes after Create:
    //       (a) ASC navigates straight to /apps/<id> — created.
    //       (b) ASC parks on a post-create dialog that says the app "has been
    //           created" (e.g. "user access settings could not be saved" — benign;
    //           all users have access by default). The app record exists; we click
    //           "Go to App Information" to land on /apps/<id> and read its id.
    //       (c) The create dialog lingers with a validation error (duplicate name
    //           or SKU). A real failure — surfaced verbatim.
    //     "has been created" is checked BEFORE the error scan so the benign
    //     interstitial is never misread as a rejection.
    const statusExpr = `(() => {
      const path = location.pathname.match(/\\/apps\\/(\\d+)/);
      if (path) return { state: 'created', appId: path[1] };
      if (/has been created/i.test(document.body.innerText || '')) return { state: 'created-interstitial' };
      const texts = [];
      document.querySelectorAll('[role="alert"], [aria-live="assertive"], [aria-live="polite"], [class*="error" i], [class*="invalid" i], [class*="validation" i]').forEach(el => {
        const t = (el.innerText || el.textContent || '').trim();
        if (t && t.length < 400) texts.push(t);
      });
      if (!texts.length) {
        const dlg = (document.querySelector('[role="dialog"]') || document.body);
        const line = (dlg.innerText || '').split('\\n').map(s => s.trim())
          .find(s => /already (being used|in use|exists|taken)|not available|must be unique|another app|choose a different|unavailable/i.test(s));
        if (line) texts.push(line);
      }
      const err = texts.find(t => /already|not available|unique|in use|taken|unavailable|different|SKU|name/i.test(t));
      if (err) return { state: 'error', msg: err };
      const dlgOpen = !!document.getElementById('name') || !!document.getElementById('bundleId');
      return { state: dlgOpen ? 'pending' : 'unknown' };
    })()`;
    let result = null;
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      const s = await evaluate(tabId, statusExpr);
      if (s && s.state === 'created') { result = { ok: true, created: true, appId: s.appId, note: 'Created the app record (ASC id ' + s.appId + ').' }; break; }
      if (s && s.state === 'created-interstitial') {
        // App exists; dismiss the interstitial by going to App Information so the
        // tab lands on /apps/<id> (and isn't left stuck on the dialog).
        await clickEl(tabId, `[...document.querySelectorAll('a,button')].find(e => /go to app information/i.test(e.textContent||''))`);
        const nav = await waitFor(tabId, `/\\/apps\\/\\d+/.test(location.pathname)`, 8000);
        const appId = nav ? await evaluate(tabId, `(location.pathname.match(/\\/apps\\/(\\d+)/)||[])[1] || null`) : null;
        result = { ok: true, created: true, appId, note: 'Created the app record' + (appId ? ' (ASC id ' + appId + ')' : '') + '. (App Store Connect could not auto-set user access — harmless; all users have access by default.)' };
        break;
      }
      if (s && s.state === 'error') { result = { ok: false, error: 'App Store Connect rejected the app: ' + s.msg }; break; }
      await sleep(500);
    }
    if (!result) {
      const last = await evaluate(tabId, statusExpr);
      result = { ok: false, error: 'Clicked Create but the app was not created' + (last && last.msg ? ': ' + last.msg : ' — the dialog never opened the new app page, so it was likely rejected (e.g. duplicate name or SKU).') };
    }
    log('create result =', JSON.stringify(result));
    return result;
  } finally {
    await detach(tabId);
  }
}

// ---- task entry ------------------------------------------------------------
async function handleAscTask(msg) {
  if (msg.task === 'createApp') {
    const { shipmateExport } = await chrome.storage.local.get('shipmateExport');
    const appName = (shipmateExport && shipmateExport.appName) || 'App';
    const slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
    const q = ' - Mark Demo';
    let base = appName.trim(); if (base.length > 30 - q.length) base = base.slice(0, 30 - q.length).trim();
    const name = (base + q).slice(0, 30);
    const sku = 'mark_demo_' + (slug(appName) || 'app');
    const tab = await chrome.tabs.create({ url: ASC_ORIGIN + '/', active: false });  // BACKGROUND: the debugger banner lives on this hidden tab
    await markManaged(tab.id);
    cdpCreateApp(tab.id, { bundleId: msg.bundleId || null, name, sku })
      .then((result) => { relayResult('createApp', result); if (result && result.created) setTimeout(() => closeManaged(tab.id), 800); })
      .catch((e) => relayResult('createApp', { ok: false, error: String(e) }));
    return { ok: true, tabId: tab.id };
  }

  // autoPrivacy: content-script path (unchanged).
  const { ascAppId } = await chrome.storage.local.get('ascAppId');
  let appId = msg.appId || ascAppId || null;
  if (!appId) {
    const tabs = await chrome.tabs.query({ url: ASC_ORIGIN + '/apps/*' });
    for (const t of tabs) { const m = (t.url || '').match(/\/apps\/(\d+)/); if (m) { appId = m[1]; break; } }
  }
  await chrome.storage.local.set({ pendingAscTask: { task: msg.task, submit: !!msg.submit, bundleId: msg.bundleId || null, ts: Date.now(), managed: true } });
  const url = appId ? `${ASC_ORIGIN}/apps/${appId}/distribution/privacy` : ASC_ORIGIN + '/';
  const tab = await chrome.tabs.create({ url, active: true });
  await markManaged(tab.id);
  setTimeout(() => { isManaged(tab.id).then((m) => { if (m) closeManaged(tab.id); }); }, 120000);
  return { ok: true, tabId: tab.id };
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === 'ascTask') { handleAscTask(msg).then(reply, (e) => reply({ ok: false, error: String(e) })); return true; }
  if (msg && msg.type === 'ascSignedIn') {   // #37: ASC tab reports signed-in → tell Shipmate
    chrome.tabs.query({ url: 'https://mtgrimm17.github.io/shipmate-prototype/*' }, (tabs) => {
      (tabs || []).forEach((t) => chrome.tabs.sendMessage(t.id, { type: 'ascSignedIn' }, () => void chrome.runtime.lastError));
    });
    return false;
  }
  if (msg && msg.type === 'ascTaskDone') {   // from content-asc (autoPrivacy path)
    relayResult(msg.task, msg.result);
    const id = sender.tab && sender.tab.id;
    const r = msg.result || {};
    if (id != null && (r.created || r.done)) isManaged(id).then((m) => { if (m) setTimeout(() => closeManaged(id), 600); });
    return false;
  }
  return false;
});

// If the user closes a tab we're debugging, Chrome detaches automatically; clean
// our managed list so we don't try to close it again.
chrome.tabs.onRemoved.addListener((id) => { unmarkManaged(id); });

chrome.runtime.onInstalled.addListener(function () {});
